/* =========================================================
   TELES ADS — main.js
   GSAP 3.13 (ScrollTrigger, SplitText, DrawSVG) + Lenis.
   Hidden start states are set here, never in CSS, so the page
   still works if a CDN fails or motion is reduced.
   ========================================================= */
(function () {
  "use strict";

  var html = document.documentElement;
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var canHover = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  var hasGSAP = !!(window.gsap && window.ScrollTrigger && window.SplitText && window.DrawSVGPlugin);
  var animated = hasGSAP && !reduce;
  var lenis = null;
  var loaderDone = false;

  function $(s, c) { return (c || document).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); }
  function isMobile() { return window.innerWidth < 768; }
  function finishLoading() {
    if (loaderDone) return;
    loaderDone = true;
    html.classList.remove("is-loading");
    document.dispatchEvent(new Event("loader:done"));
  }
  function onLoaderDone(fn) {
    if (loaderDone) fn(); else document.addEventListener("loader:done", fn, { once: true });
  }

  html.classList.add("js");
  var yearEl = $("[data-year]");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------- Services path data (viewBox 0 0 1000 2400) ---------- */
  var SERVICE_PATH =
    "M1040 60 C880 30 700 60 620 160 C540 260 640 360 560 380 C480 400 470 300 540 300 " +
    "C640 300 640 470 500 560 C360 650 180 640 200 780 C220 900 520 860 700 900 " +
    "C880 940 900 1080 760 1120 C640 1150 520 1120 480 1220 C440 1320 600 1360 560 1280 " +
    "C520 1200 380 1300 330 1420 C280 1540 420 1600 600 1620 C780 1640 860 1720 800 1840 " +
    "C740 1960 560 1900 470 2000 C380 2100 460 2200 380 2260 C300 2320 120 2320 -40 2400";
  $$(".services-path path").forEach(function (p) { p.setAttribute("d", SERVICE_PATH); });
  placeServices();
  window.addEventListener("resize", debounce(function () { placeServices(); if (hasGSAP) ScrollTrigger.refresh(); }, 200));

  if (!animated) {
    finishLoading();
    initMenu(false);
    initContact(false);
    initFaq(false);
    initDeck(false);
    initAgent(false);
    initGlobe();
    return;
  }

  gsap.registerPlugin(ScrollTrigger, SplitText, DrawSVGPlugin);

  /* ---------- Smooth scroll ---------- */
  if (window.Lenis) {
    lenis = new Lenis({ duration: canHover ? 1.5 : 1.0, wheelMultiplier: 0.85, smoothWheel: true });
    lenis.stop();
    lenis.on("scroll", ScrollTrigger.update);
    gsap.ticker.add(function (t) { lenis.raf(t * 1000); });
    gsap.ticker.lagSmoothing(0);
  }

  var fontsReady = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
  Promise.race([fontsReady, new Promise(function (r) { setTimeout(r, 2500); })]).then(function () {
    placeServices();
    setupHero();
    runLoader();
    initRibbon();
    initAbout();
    initDualHeadings();
    initSplitHeadings();
    initProjects();
    initProjectsEnd();
    initServices();
    initSlider();
    initMeasured();
    initSectors();
    initAgent(true);
    initGlobe();
    initDeck(true);
    initFaq(true);
    initFooter();
    initKineticLinks();
    initMagnetic();
    initMenu(true);
    initContact(true);
    initAnchors();
  });

  /* =========================================================
     LOADER — trail draws, letters pop, pink then orange strokes
     slither out of the viewport to reveal the page
     ========================================================= */
  function runLoader() {
    var loader = $(".loader");
    var exited = false;
    function exit() {
      if (exited) return; exited = true;
      finishLoading();
      if (lenis) lenis.start();
      ScrollTrigger.refresh();
    }
    setTimeout(exit, 6000);   // hard safety: never lock the visitor out

    var tMark = $$(".lg-0", loader);
    var letters = $$(".lg:not(.lg-0)", loader);
    var pink = $(".wipe-pink", loader), orange = $(".wipe-orange", loader);

    gsap.set([pink, orange], { drawSVG: "0% 100%" });
    gsap.set(tMark.concat(letters), { drawSVG: "0%" });

    var tl = gsap.timeline();
    tl.to(tMark, { drawSVG: "100%", duration: 0.9, ease: "power2.inOut", stagger: 0.25 })
      .to(letters, { drawSVG: "100%", duration: 0.45, ease: "power2.out", stagger: 0.06 }, "-=0.3")
      .fromTo(".loader-mark", { scale: 0.96 }, { scale: 1, duration: 0.6, ease: "back.out(3)" }, "-=0.2")
      .add("wipe", "+=0.25")
      .to(pink, { drawSVG: "100% 100%", duration: 0.85, ease: "power3.inOut" }, "wipe")
      .to(".loader-logo", { opacity: 0, duration: 0.25 }, "wipe+=0.2")
      .to(orange, { drawSVG: "100% 100%", duration: 0.85, ease: "power3.inOut" }, "wipe+=0.22")
      .add(exit, "wipe+=0.55");
  }

  /* =========================================================
     HERO — lines rise, pills pop with masked text, swirls draw,
     illustration pops in then floats
     ========================================================= */
  function setupHero() {
    var lines = $$(".hero-line");
    var splits = lines.map(function (l) { return SplitText.create(l, { type: "lines", mask: "lines" }); });
    var pills = $$(".hero-pills .pill");
    pills.forEach(wrapPillText);
    var swirls = $$(".hero-swirl path");
    var arts = $$(".hero-art .art, .hero-art .art-plus");
    var trail = $(".art-trail");
    var sparks = $$(".spark");

    splits.forEach(function (s) { gsap.set(s.lines, { yPercent: 105 }); });
    pills.forEach(function (p) { gsap.set(p, { rotation: readRot(p), scale: 0, y: 30 }); gsap.set($(".pill-mask > span", p), { yPercent: 105 }); });
    gsap.set(swirls, { drawSVG: "0%", strokeWidth: 0 });
    gsap.set(arts, { scale: 0, transformOrigin: "50% 100%", transformBox: "fill-box" });
    gsap.set(trail, { opacity: 0 });
    gsap.set(sparks, { scale: 0, transformOrigin: "50% 50%", transformBox: "fill-box" });

    var tl = gsap.timeline({ paused: true });
    splits.forEach(function (s, i) {
      tl.to(s.lines, { yPercent: 0, duration: 1.1, ease: "power4.out" }, i * 0.12);
    });
    pills.forEach(function (p, i) {
      var t = 0.45 + i * 0.12;
      tl.to(p, { scale: 1, y: 0, duration: 0.75, ease: "back.out(2.2)" }, t)
        .to($(".pill-mask > span", p), { yPercent: 0, duration: 0.6, ease: "power3.out" }, t + 0.18);
    });
    tl.to(swirls, { drawSVG: "100%", strokeWidth: function (i, el) { return isMobile() ? 20 : 26; }, duration: 1.4, ease: "power2.inOut", stagger: 0.1 }, 0.2)
      .to(arts, { scale: 1, duration: 0.9, ease: "back.out(1.8)", stagger: 0.12 }, 0.5)
      .to(trail, { opacity: 1, duration: 0.4 }, 1)
      .to(sparks, { scale: 1, duration: 0.6, ease: "back.out(3)", stagger: 0.1 }, 1.1)
      .add(idle, 1.6);

    function idle() {
      gsap.to(".art-plane", { y: -14, rotation: 3, duration: 1.8, ease: "sine.inOut", yoyo: true, repeat: -1 });
      gsap.to(".art-phone", { y: 8, duration: 2.2, ease: "sine.inOut", yoyo: true, repeat: -1 });
      gsap.to(".art-mega", { rotation: -3, duration: 1.4, ease: "sine.inOut", yoyo: true, repeat: -1 });
      gsap.to(".art-plus", { scale: 1.12, duration: 0.7, ease: "sine.inOut", yoyo: true, repeat: -1 });
      gsap.to(".art-mega .sl", { opacity: 0.2, duration: 0.5, stagger: 0.15, yoyo: true, repeat: -1 });
      gsap.to(trail, { strokeDashoffset: -44, duration: 1.2, ease: "none", repeat: -1 });
      gsap.to(sparks, { scale: 0.6, rotation: 45, duration: 1.2, ease: "sine.inOut", yoyo: true, repeat: -1, stagger: 0.3 });
    }
    onLoaderDone(function () { tl.play(); });
  }

  /* =========================================================
     RIBBON — orange stroke draws in, text loops along the curve
     ========================================================= */
  function initRibbon() {
    var bg = $(".ribbon-bg"), mask = $(".ribbon-mask-path"), tp = $(".ribbon-tp"), unit = $(".ribbon-unit");
    var group = $(".ribbon-text-group");
    if (!bg || !tp) return;
    gsap.set([bg, mask], { drawSVG: "100% 100%" });
    var len = unit ? unit.getComputedTextLength() : 1600;
    gsap.to(tp, { attr: { startOffset: -len }, duration: len / 75, ease: "none", repeat: -1 });
    gsap.to([bg, mask], {
      drawSVG: "0% 100%", duration: 1.3, ease: "power2.out",
      scrollTrigger: { trigger: ".ribbon", start: "top 85%", once: true },
      onComplete: function () { group.removeAttribute("mask"); }
    });
  }

  /* =========================================================
     ABOUT — pinned; characters sweep pale → orange → ink,
     pills pop at milestones
     ========================================================= */
  function initAbout() {
    var text = $(".about-text");
    if (!text) return;
    var split = SplitText.create(text, { type: "words,chars", charsClass: "ch" });
    var chars = split.chars;
    var pills = $$(".about-pill");
    pills.forEach(function (p) { wrapPillText(p); gsap.set(p, { rotation: readRot(p), scale: 0 }); });
    gsap.set(chars, { color: "#F8B996" });

    var tl = gsap.timeline({
      scrollTrigger: { trigger: ".about-pin", start: "top top", end: function () { return "+=" + window.innerHeight * (isMobile() ? 1.4 : 1.8); }, pin: true, scrub: 0.8, anticipatePin: 1 }
    });
    var step = 0.04;
    chars.forEach(function (c, i) {
      tl.to(c, { color: "#FF5C00", scale: 1.08, duration: 0.12, ease: "power2.out" }, i * step)
        .to(c, { color: "#0C0C0D", scale: 1, duration: 0.2, ease: "power2.inOut" }, i * step + 0.12);
    });
    var total = chars.length * step;
    pills.forEach(function (p, i) {
      tl.to(p, { scale: 1, duration: 0.3, ease: "back.out(2.5)" }, total * (0.2 + i * 0.3));
    });
  }

  /* =========================================================
     DUAL HEADINGS — orange copy behind, drifts 1–4px from cursor
     ========================================================= */
  function initDualHeadings() {
    var shadows = [];
    $$(".dual").forEach(function (h) {
      var wrap = document.createElement("div");
      wrap.className = "dual-wrap";
      h.parentNode.insertBefore(wrap, h);
      wrap.appendChild(h);
      var clone = h.cloneNode(true);
      clone.removeAttribute("data-split");
      clone.classList.add("dual-shadow");
      clone.setAttribute("aria-hidden", "true");
      wrap.insertBefore(clone, h);
      gsap.set(clone, { opacity: 0 });
      ScrollTrigger.create({ trigger: wrap, start: "top 80%", once: true, onEnter: function () { gsap.to(clone, { opacity: 1, duration: 0.5, delay: 0.8 }); } });
      shadows.push({ x: gsap.quickTo(clone, "x", { duration: 0.6, ease: "power3" }), y: gsap.quickTo(clone, "y", { duration: 0.6, ease: "power3" }) });
    });
    shadows.forEach(function (s) { s.x(3); s.y(3); });
    if (!canHover) return;
    window.addEventListener("pointermove", function (e) {
      var nx = (e.clientX / window.innerWidth) * 2 - 1, ny = (e.clientY / window.innerHeight) * 2 - 1;
      var mag = 1 + 3 * Math.min(1, Math.hypot(nx, ny));
      var a = Math.atan2(ny, nx) + Math.PI;
      shadows.forEach(function (s) { s.x(Math.cos(a) * mag); s.y(Math.sin(a) * mag); });
    });
  }

  /* ---------- Line-by-line heading reveals ---------- */
  function initSplitHeadings() {
    $$("[data-split]").forEach(function (h) {
      if (h.classList.contains("footer-title")) return;
      SplitText.create(h, {
        type: "lines", mask: "lines", autoSplit: true,
        onSplit: function (self) {
          return gsap.from(self.lines, { yPercent: 110, duration: 1, ease: "power4.out", stagger: 0.12, scrollTrigger: { trigger: h, start: "top 85%", once: true } });
        }
      });
    });
  }

  /* =========================================================
     PROJECTS — clip mask grows from 15% with 3D tilt; hover draws
     a brush stroke then reveals a colour panel through a mask
     ========================================================= */
  function initProjects() {
    var cards = $$(".project");
    cards.forEach(function (card) {
      var media = $(".project-media", card);
      var mask = document.createElement("div");
      mask.className = "project-mask";
      media.parentNode.insertBefore(mask, media);
      mask.appendChild(media);
      gsap.set(mask, { clipPath: "inset(42.5% 42.5% 42.5% 42.5% round 36px)" });
      gsap.set(media, { scale: 1.45, rotationX: 18, rotationY: -12, transformPerspective: 1200 });
      gsap.set($(".project-meta", card), { opacity: 0, y: 20 });

      var pf = $(".pf-path", card), panel = $(".project-panel", card), label = $(".project-hover", card), arrow = $(".project-arrow", card);
      gsap.set(pf, { drawSVG: "0%", opacity: 0 });
      gsap.set(label, { y: 20 });
      var hover = gsap.timeline({ paused: true });
      hover.set(pf, { opacity: 1 })
        .to(pf, { drawSVG: "100%", duration: 0.5, ease: "power2.in" })
        .fromTo(panel, { clipPath: "inset(0% 0% 100% 0%)" }, { clipPath: "inset(0% 0% 0% 0%)", duration: 0.55, ease: "power3.out" }, 0.3)
        .to(pf, { opacity: 0, duration: 0.2 }, 0.7)
        .to(label, { opacity: 1, y: 0, duration: 0.3 }, 0.65);
      if (canHover) {
        card.addEventListener("mouseenter", function () {
          hover.timeScale(1).play();
          gsap.fromTo(arrow, { rotation: 0 }, { rotation: -45, duration: 0.25, ease: "power2.out", onComplete: function () { gsap.to(arrow, { rotation: 0, duration: 0.9, ease: "elastic.out(1.2, 0.3)" }); } });
        });
        card.addEventListener("mouseleave", function () { hover.timeScale(2).reverse(); });
      }
    });
    ScrollTrigger.batch(".project-mask", {
      start: "top 90%", once: true,
      onEnter: function (masks) {
        gsap.to(masks, { clipPath: "inset(0% 0% 0% 0% round 20px)", duration: 1.25, ease: "power3.out", stagger: 0.12 });
        gsap.to(masks.map(function (m) { return m.firstElementChild; }), { scale: 1, rotationX: 0, rotationY: 0, duration: 1.25, ease: "power3.out", stagger: 0.12 });
        gsap.to(masks.map(function (m) { return $(".project-meta", m.parentNode); }), { opacity: 1, y: 0, duration: 0.8, ease: "power3.out", delay: 0.5, stagger: 0.12 });
      }
    });
  }

  function initProjectsEnd() {
    var end = $(".projects-end");
    if (!end) return;
    var title = $(".projects-end-title", end);
    var split = SplitText.create(title, { type: "lines", mask: "lines" });
    var pills = $$(".pe-pill", end);
    var btn = $(".talk", end);
    pills.forEach(function (p) { wrapPillText(p); gsap.set(p, { rotation: readRot(p), scale: 0 }); });
    gsap.set(split.lines, { yPercent: 110 });
    gsap.set(btn, { scale: 0 });
    var tl = gsap.timeline({ scrollTrigger: { trigger: end, start: "top 75%", once: true } });
    tl.to(split.lines, { yPercent: 0, duration: 1, ease: "power4.out", stagger: 0.12 })
      .to(pills, { scale: 1, duration: 0.6, ease: "back.out(2.5)", stagger: 0.12 }, 0.5)
      .to(btn, { scale: 1, duration: 0.6, ease: "back.out(2.5)" }, 0.8);
  }

  /* =========================================================
     SERVICES — the line draws as you scroll; each service's icon
     expands from zero width (pushing the words apart) and its
     description bubble pops in when the line reaches it
     ========================================================= */
  function initServices() {
    var dark = $(".sp-dark");
    var layers = $$(".service");
    gsap.set(dark, { drawSVG: "0%" });
    layers.forEach(function (li) {
      var icon = $(".service-svg", li), para = $(".service-para", li);
      icon.dataset.w = icon.getBoundingClientRect().width;
      gsap.set(icon, { width: 0, scale: 0, opacity: 0 });
      gsap.set(para, { scale: 0, rotation: 0, opacity: 0, transformOrigin: "20% 0%" });
    });
    var tl = gsap.timeline({
      scrollTrigger: { trigger: ".services-stage", start: "top 70%", end: "bottom 70%", scrub: 1.2, invalidateOnRefresh: true }
    });
    tl.to(dark, { drawSVG: "100%", ease: "none", duration: 1 }, 0);
    var n = layers.length;
    layers.forEach(function (li, i) {
      var icon = $(".service-svg", li), para = $(".service-para", li);
      var t = Math.max(0, (i + 0.5) / n - 0.04);
      tl.to(icon, { width: function () { return parseFloat(icon.dataset.w) || 60; }, scale: 1, opacity: 1, duration: 0.14, ease: "back.out(3.5)" }, t)
        .to(para, { scale: 1, rotation: -5, opacity: 1, duration: 0.14, ease: "back.out(3.5)" }, t + 0.02);
    });
  }

  /* Position each service on the path at an even share of its length. */
  function placeServices() {
    var stage = $(".services-stage"), path = $(".sp-dark");
    if (!stage || !path || !path.getTotalLength) return;
    var layers = $$(".service");
    var W = stage.clientWidth, H = stage.clientHeight;
    var L = path.getTotalLength();
    var g = parseFloat(getComputedStyle(document.documentElement).fontSize) * 1.25;
    layers.forEach(function (li, i) {
      var pt = path.getPointAtLength(L * (i + 0.5) / layers.length);
      var x = pt.x / 1000 * W, y = pt.y / 2400 * H;
      var block = $(".service-block", li), para = $(".service-para", li);
      var icon = $(".service-svg", li);
      var bw = block.scrollWidth + (icon && icon.style.width === "0px" ? parseFloat(icon.dataset.w || 0) : 0);
      var pw = para ? para.offsetWidth : 0;
      var left = bw / 2 + g;
      var right = W - Math.max(bw / 2, bw * 0.05 + pw * (isMobile() ? 0.65 : 1)) - g;
      x = Math.min(Math.max(x, left), Math.max(left, right));
      li.style.left = x + "px";
      li.style.top = y + "px";
    });
  }

  /* =========================================================
     PRINCIPLES DECK — stacked, tilted cards; the top card flies
     up and slides back under the pile
     ========================================================= */
  function initDeck(anim) {
    var panel = $(".deck-panel"), deck = $(".deck");
    if (!deck) return;
    var cards = $$(".deck-card", deck);
    var ticksWrap = $(".deck-ticks");
    var rots = [0, -5, 6, -9, 4, -3];
    var order = cards.map(function (_, i) { return i; });
    var busy = false;

    var ticks = cards.map(function (c, i) {
      var b = document.createElement("button");
      b.type = "button"; b.setAttribute("role", "tab"); b.setAttribute("aria-label", "Card " + (i + 1));
      b.addEventListener("click", function (e) { e.stopPropagation(); goTo(i); });
      ticksWrap.appendChild(b);
      return b;
    });

    function layout(instant) {
      order.forEach(function (ci, pos) {
        var c = cards[ci];
        c.style.zIndex = String(cards.length - pos);
        c.setAttribute("aria-hidden", pos === 0 ? "false" : "true");
        var r = rots[pos % rots.length];
        if (anim && !instant) gsap.to(c, { rotation: r, y: 0, duration: 0.6, ease: "power3.out" });
        else if (anim) gsap.set(c, { rotation: r, y: 0 });
        else c.style.transform = "rotate(" + r + "deg)";
      });
      ticks.forEach(function (t, i) { t.setAttribute("aria-selected", String(i === order[0])); });
    }

    function next() {
      if (busy) return;
      var top = cards[order[0]];
      if (!anim) { order.push(order.shift()); layout(true); return; }
      busy = true;
      gsap.timeline({ onComplete: function () { busy = false; } })
        .to(top, { yPercent: -115, rotation: gsap.utils.random(-12, 12), duration: 0.45, ease: "power2.in" })
        .add(function () { order.push(order.shift()); layout(); top.style.zIndex = "0"; })
        .to(top, { yPercent: 0, duration: 0.6, ease: "power3.out" });
    }
    function prev() {
      if (busy) return;
      var bottom = cards[order[order.length - 1]];
      if (!anim) { order.unshift(order.pop()); layout(true); return; }
      busy = true;
      gsap.timeline({ onComplete: function () { busy = false; } })
        .to(bottom, { yPercent: 115, rotation: gsap.utils.random(-12, 12), duration: 0.45, ease: "power2.in" })
        .add(function () { order.unshift(order.pop()); layout(); bottom.style.zIndex = String(cards.length + 1); })
        .to(bottom, { yPercent: 0, rotation: 0, duration: 0.6, ease: "power3.out" });
    }
    function goTo(i) {
      if (order[0] === i || busy) return;
      var target = cards[i];
      if (!anim) { order.splice(order.indexOf(i), 1); order.unshift(i); layout(true); return; }
      busy = true;
      gsap.timeline({ onComplete: function () { busy = false; } })
        .to(target, { yPercent: 115, duration: 0.4, ease: "power2.in" })
        .add(function () { order.splice(order.indexOf(i), 1); order.unshift(i); layout(); target.style.zIndex = String(cards.length + 1); })
        .to(target, { yPercent: 0, rotation: 0, duration: 0.6, ease: "power3.out" });
    }

    layout(true);
    panel.addEventListener("click", function (e) { if (!e.target.closest("a")) next(); });
    $(".deck-next").addEventListener("click", function (e) { e.stopPropagation(); next(); });
    panel.addEventListener("keydown", function (e) {
      if (e.key === "ArrowDown" || e.key === "ArrowRight") { e.preventDefault(); next(); }
      if (e.key === "ArrowUp" || e.key === "ArrowLeft") { e.preventDefault(); prev(); }
    });
    var sy = null;
    panel.addEventListener("touchstart", function (e) { sy = e.touches[0].clientY; }, { passive: true });
    panel.addEventListener("touchend", function (e) {
      if (sy === null) return;
      var dy = e.changedTouches[0].clientY - sy; sy = null;
      if (Math.abs(dy) > 30) { dy < 0 ? next() : prev(); }
    });

    if (anim) {
      gsap.from(cards, { y: 120, opacity: 0, rotation: 0, duration: 1, ease: "back.out(1.4)", stagger: 0.08, scrollTrigger: { trigger: panel, start: "top 75%", once: true }, onComplete: function () { layout(); } });
      gsap.from(".deck-next", { scale: 0, duration: 0.6, ease: "back.out(3)", scrollTrigger: { trigger: panel, start: "top 85%", once: true } });
    }
  }

  /* =========================================================
     FAQ — chat bubbles. Question shrinks and gets an outline,
     the answer bubble grows from the bottom-right with the logo.
     One item is always open.
     ========================================================= */
  function initFaq(anim) {
    var items = $$(".faq-item");
    var active = null;
    function openW() { return window.innerWidth < 992 ? "75%" : "50%"; }

    function open(item, instant) {
      var q = $(".faq-q-btn", item), a = $(".faq-a", item), p = $("p", a), logo = $(".faq-logo", a);
      item.classList.add("is-open");
      q.setAttribute("aria-expanded", "true");
      if (!anim) { a.style.height = "auto"; return; }
      var d = instant ? 0 : 1;
      gsap.timeline()
        .to(q, { width: openW(), duration: 0.5 * d, ease: "power3.inOut" })
        .to(a, { height: "auto", duration: 0.5 * d, ease: "power3.out" }, 0.1 * d)
        .fromTo(p, { scale: 0 }, { scale: 1, duration: 0.6 * d, ease: "back.out(1.6)" }, 0.1 * d)
        .fromTo(logo, { scale: 0 }, { scale: 1, duration: 0.5 * d, ease: "back.out(3)" }, 0.3 * d)
        .fromTo(p, { color: "rgba(12,12,13,0)" }, { color: "rgba(12,12,13,1)", duration: 0.4 * d }, 0.45 * d);
    }
    function close(item) {
      var q = $(".faq-q-btn", item), a = $(".faq-a", item), p = $("p", a), logo = $(".faq-logo", a);
      item.classList.remove("is-open");
      q.setAttribute("aria-expanded", "false");
      if (!anim) { a.style.height = "0px"; return; }
      gsap.timeline()
        .to(p, { color: "rgba(12,12,13,0)", duration: 0.15 })
        .to([p, logo], { scale: 0, duration: 0.35, ease: "power3.in" }, 0.1)
        .to(a, { height: 0, duration: 0.4, ease: "power3.inOut" }, 0.2)
        .to(q, { width: "100%", duration: 0.45, ease: "power3.inOut" }, 0.25);
    }

    items.forEach(function (item, i) {
      var q = $(".faq-q-btn", item);
      q.setAttribute("aria-expanded", "false");
      q.addEventListener("click", function () {
        if (active === item) return;           // one always stays open
        if (active) close(active);
        open(item); active = item;
      });
    });
    if (items[0]) { open(items[0], true); active = items[0]; }
    window.addEventListener("resize", debounce(function () { if (active && anim) gsap.set($(".faq-q-btn", active), { width: openW() }); }, 150));

    if (anim) {
      ScrollTrigger.batch(".faq-item", { start: "top 92%", once: true, onEnter: function (els) { gsap.from(els, { y: 40, opacity: 0, duration: 0.8, ease: "power3.out", stagger: 0.06 }); } });
      gsap.from(".faq-art .faq-bot", { y: 80, opacity: 0, duration: 1, ease: "back.out(1.6)", scrollTrigger: { trigger: ".faq-art", start: "top 90%", once: true } });
      gsap.from(".faq-art .faq-q", { scale: 0, transformOrigin: "50% 50%", transformBox: "fill-box", duration: 0.7, ease: "back.out(3)", stagger: 0.15, delay: 0.4, scrollTrigger: { trigger: ".faq-art", start: "top 90%", once: true } });
      gsap.to(".faq-art .faq-q", { y: -10, duration: 1.4, ease: "sine.inOut", yoyo: true, repeat: -1, stagger: 0.4 });
      gsap.to(".faq-art .eye", { scaleY: 0.1, duration: 0.12, yoyo: true, repeat: -1, repeatDelay: 2.6 });
    }
  }

  /* =========================================================
     FOOTER — heading bounces up line by line; the giant wordmark
     stretches with scroll and springs back at the bottom
     ========================================================= */
  function initFooter() {
    var title = $(".footer-title");
    if (title) {
      var s = SplitText.create(title, { type: "lines", mask: "lines" });
      gsap.from(s.lines, { yPercent: 110, duration: 1.1, ease: "back.out(1.6)", stagger: 0.12, scrollTrigger: { trigger: ".footer", start: "top 70%", once: true } });
    }
    var mark = $(".footer-mark");
    if (!mark) return;
    gsap.set(mark, { scaleY: 0.15 });
    var setY = gsap.quickTo(mark, "scaleY", { duration: 0.5, ease: "power3" });
    var settled = false;
    ScrollTrigger.create({
      trigger: ".footer", start: "top bottom", end: "bottom bottom",
      onUpdate: function (self) {
        if (self.progress > 0.985) {
          if (!settled) { settled = true; gsap.to(mark, { scaleY: 1, duration: 1.4, ease: "elastic.out(1, 0.3)", overwrite: true }); }
          return;
        }
        if (settled && self.progress > 0.9) return;
        settled = false;
        setY(0.15 + 1.2 * self.progress);
      }
    });
  }

  /* ---------- Kinetic letter hover (footer and contact links) ---------- */
  function initKineticLinks() {
    if (!canHover) return;
    $$(".f-link, .contact-link").forEach(function (link) {
      var s = SplitText.create(link, { type: "chars", charsClass: "ch" });
      link.addEventListener("mouseenter", function () {
        gsap.to(s.chars, {
          keyframes: [
            { y: -6, rotation: function () { return gsap.utils.random(-14, 14); }, scale: 1.18, duration: 0.18, ease: "power2.out" },
            { y: 0, rotation: 0, scale: 1, duration: 0.55, ease: "elastic.out(1, 0.4)" }
          ],
          stagger: 0.02, overwrite: true
        });
      });
    });
  }

  /* =========================================================
     MAGNETIC "LET'S TALK" — orange fill grows from the dot,
     button follows the cursor, springs back on leave
     ========================================================= */
  function initMagnetic() {
    if (!canHover) return;
    $$(".magnetic").forEach(function (btn) {
      var fill = $(".talk-fill", btn), dot = $(".talk-dot svg", btn), text = $(".talk-text", btn);
      var bx = gsap.quickTo(btn, "x", { duration: 0.5, ease: "power3" }), by = gsap.quickTo(btn, "y", { duration: 0.5, ease: "power3" });
      var tx = gsap.quickTo(text, "x", { duration: 0.5, ease: "power3" }), ty = gsap.quickTo(text, "y", { duration: 0.5, ease: "power3" });
      var rect = null, loop = null;
      btn.addEventListener("mouseenter", function () {
        rect = btn.getBoundingClientRect();
        gsap.to(fill, { scale: (rect.width / fill.offsetWidth) * 2.4, duration: 0.55, ease: "power3.out" });
        loop = gsap.timeline({ repeat: -1, repeatDelay: 0.3 })
          .to(dot, { rotation: 45, duration: 0.35, ease: "back.out(3)" })
          .to(dot, { rotation: 0, duration: 0.5, ease: "elastic.out(1, 0.4)" }, "+=0.2");
      });
      btn.addEventListener("mousemove", function (e) {
        if (!rect) rect = btn.getBoundingClientRect();
        var cx = rect.left + rect.width / 2 - (gsap.getProperty(btn, "x") || 0);
        var cy = rect.top + rect.height / 2 - (gsap.getProperty(btn, "y") || 0);
        var dx = e.clientX - cx, dy = e.clientY - cy;
        bx(dx * 0.3); by(dy * 0.45); tx(dx * 0.1); ty(dy * 0.1);
      });
      btn.addEventListener("mouseleave", function () {
        rect = null;
        if (loop) { loop.kill(); loop = null; }
        gsap.to(dot, { rotation: 0, duration: 0.4 });
        gsap.to([btn, text], { x: 0, y: 0, duration: 1, ease: "elastic.out(1, 0.35)", overwrite: "auto" });
        gsap.to(fill, { scale: 0, duration: 0.45, ease: "power3.inOut" });
      });
    });
  }

  /* ---------- Mobile menu ---------- */
  function initMenu(anim) {
    var toggle = $(".menu-toggle"), menu = $("#menu");
    if (!toggle || !menu) return;
    var open = false;
    function set(state) {
      open = state;
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      if (open) {
        menu.hidden = false;
        if (lenis) lenis.stop();
        if (anim) {
          gsap.fromTo(menu, { clipPath: "circle(0% at 95% 3%)" }, { clipPath: "circle(150% at 95% 3%)", duration: 0.8, ease: "power3.inOut" });
          gsap.fromTo($$(".menu-links a, .menu .talk", menu), { yPercent: 100, opacity: 0 }, { yPercent: 0, opacity: 1, duration: 0.7, ease: "power4.out", stagger: 0.06, delay: 0.25 });
        }
      } else {
        var hide = function () { menu.hidden = true; if (lenis) lenis.start(); };
        if (anim) gsap.to(menu, { clipPath: "circle(0% at 95% 3%)", duration: 0.6, ease: "power3.inOut", onComplete: hide });
        else hide();
      }
    }
    toggle.addEventListener("click", function () { set(!open); });
    $$("a", menu).forEach(function (a) { a.addEventListener("click", function () { if (open) set(false); }); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && open) set(false); });
    document.addEventListener("contact:open", function () { if (open) set(false); });
  }

  /* =========================================================
     CONTACT OVERLAY — orange stroke expands to fill the screen,
     then the content pops in; Esc / Close reverses it
     ========================================================= */
  function initContact(anim) {
    var modal = $(".contact");
    if (!modal) return;
    var wipe = $(".contact-wipe path", modal), closeBtn = $(".contact-close", modal);
    var items = $$(".contact-logo, .contact-close, .contact-title, .contact-copy, .contact-h, .contact-link, .contact-pills .pill, .contact-art", modal);
    var lastFocus = null, isOpen = false, tl = null;
    if (!anim) modal.style.background = "var(--orange)";

    function openIt() {
      if (isOpen) return; isOpen = true;
      document.dispatchEvent(new Event("contact:open"));
      lastFocus = document.activeElement;
      modal.hidden = false;
      if (lenis) lenis.stop(); else document.body.style.overflow = "hidden";
      if (anim) {
        if (tl) tl.kill();
        tl = gsap.timeline()
          .fromTo(wipe, { drawSVG: "0%", strokeWidth: 0 }, { drawSVG: "100%", strokeWidth: 1700, duration: 1, ease: "power3.inOut" })
          .fromTo(items, { y: 60, opacity: 0, rotation: function () { return gsap.utils.random(-5, 5); } }, { y: 0, opacity: 1, rotation: 0, duration: 0.7, ease: "back.out(1.6)", stagger: 0.045 }, "-=0.4");
      }
      setTimeout(function () { closeBtn.focus(); }, anim ? 600 : 0);
    }
    function closeIt() {
      if (!isOpen) return; isOpen = false;
      var done = function () { modal.hidden = true; if (lenis) lenis.start(); else document.body.style.overflow = ""; if (lastFocus) lastFocus.focus(); };
      if (!anim) return done();
      if (tl) tl.kill();
      tl = gsap.timeline({ onComplete: done })
        .to(items, { opacity: 0, duration: 0.25, stagger: 0.01 })
        .to(wipe, { drawSVG: "100% 100%", duration: 0.8, ease: "power3.inOut" }, "-=0.1");
    }
    document.addEventListener("click", function (e) { if (e.target.closest(".cta-btn")) { e.preventDefault(); openIt(); } });
    closeBtn.addEventListener("click", closeIt);
    document.addEventListener("keydown", function (e) {
      if (!isOpen) return;
      if (e.key === "Escape") closeIt();
      if (e.key === "Tab") {
        var f = $$("a, button", modal), first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
  }

  /* ---------- Smooth anchor links ---------- */
  function initAnchors() {
    $$('a[href^="#"]').forEach(function (a) {
      a.addEventListener("click", function (e) {
        var id = a.getAttribute("href");
        if (id.length < 2 || !lenis) return;
        var target = $(id);
        if (!target) return;
        e.preventDefault();
        lenis.scrollTo(target, { offset: id === "#top" ? 0 : -20, duration: 1.6 });
      });
    });
  }


  /* =========================================================
     INFINITE SLIDER — idle drift, speeds up with scroll velocity,
     follows scroll direction; slides shrink slightly near centre
     ========================================================= */
  function initSlider() {
    $$(".slider").forEach(function (slider) {
      var track = $(".slider-track", slider);
      var originals = $$(".slide", track);
      var level = Math.min(5, Math.max(1, parseInt(slider.dataset.speed || "1", 10)));
      var base = 1.5 * (1 + 0.3 * (level - 1));
      var setW = 0, x = 0, dir = -1, boost = 0, slides = [];

      function build() {
        $$(".slide.is-clone", track).forEach(function (c) { c.remove(); });
        var gap = parseFloat(getComputedStyle(track).columnGap) || 0;
        setW = originals.reduce(function (w, sl) { return w + sl.getBoundingClientRect().width + gap; }, 0);
        var sets = Math.max(2, Math.ceil((window.innerWidth * 3) / setW));
        for (var k = 1; k < sets; k++) originals.forEach(function (sl) {
          var c = sl.cloneNode(true); c.classList.add("is-clone"); c.setAttribute("aria-hidden", "true"); track.appendChild(c);
        });
        slides = $$(".slide", track);
      }
      build();
      window.addEventListener("resize", debounce(build, 200));
      window.addEventListener("load", build);

      var setX = gsap.quickSetter(track, "x", "px");
      var inView = true;
      ScrollTrigger.create({ trigger: slider, start: "top bottom", end: "bottom top", onToggle: function (st) { inView = st.isActive; } });
      gsap.from(slider, { opacity: 0, y: 80, duration: 1.1, ease: "power3.out", scrollTrigger: { trigger: slider, start: "top 90%", once: true } });

      gsap.ticker.add(function (t, delta) {
        if (!inView || !setW) return;
        if (lenis && lenis.direction) dir = lenis.direction > 0 ? -1 : 1;
        var v = lenis ? Math.abs(lenis.velocity) : 0;
        boost += (Math.min(v * 0.5, 22) - boost) * 0.08;
        x += (base + boost) * dir * (delta / 16.67);
        while (x <= -setW) x += setW;
        while (x > 0) x -= setW;
        setX(x);
        var cx = window.innerWidth / 2;
        slides.forEach(function (sl) {
          var r = sl.getBoundingClientRect();
          if (r.right < -200 || r.left > window.innerWidth + 200) return;
          var d = Math.min(1, Math.abs(r.left + r.width / 2 - cx) / cx);
          sl.style.transform = "scale(" + (0.95 + 0.05 * d) + ")";
        });
      });
    });
  }

  /* =========================================================
     MEASURED — funnel bars grow, counters count up, process line
     draws as you scroll and each step pops in
     ========================================================= */
  function initMeasured() {
    var bars = $$(".funnel-bar"), labels = $$(".funnel-label");
    gsap.set(bars, { scaleX: 0 });
    gsap.set(labels, { opacity: 0, x: -20 });
    gsap.timeline({ scrollTrigger: { trigger: ".funnel", start: "top 80%", once: true } })
      .to(bars, { scaleX: 1, duration: 1, ease: "power4.out", stagger: 0.12 })
      .to(labels, { opacity: 1, x: 0, duration: 0.5, ease: "power3.out", stagger: 0.12 }, 0.35)
      .from(".funnel-note", { opacity: 0, y: 10, duration: 0.5 }, 0.9);

    $$(".stat-n").forEach(function (el) {
      var to = parseFloat(el.dataset.to) || 0, o = { v: 0 };
      el.textContent = "0";
      gsap.to(o, { v: to, duration: 1.6, ease: "power2.out", snap: { v: 1 }, onUpdate: function () { el.textContent = o.v; },
        scrollTrigger: { trigger: el, start: "top 88%", once: true } });
    });
    gsap.from(".stat", { y: 50, opacity: 0, duration: 0.9, ease: "power3.out", stagger: 0.1, scrollTrigger: { trigger: ".stats", start: "top 85%", once: true } });

    var line = $(".steps-line path");
    if (line) gsap.fromTo(line, { drawSVG: "0%" }, { drawSVG: "100%", ease: "none", scrollTrigger: { trigger: ".steps", start: "top 80%", end: "bottom 60%", scrub: 1 } });
    $$(".step").forEach(function (st, i) {
      var p = $("p", st);
      var r = readRot(st);
      gsap.set(p, { rotation: 0, scale: 0 });
      gsap.timeline({ scrollTrigger: { trigger: ".steps", start: "top " + (78 - i * 4) + "%", once: true }, delay: i * 0.12 })
        .from($(".step-dot", st), { scale: 0, duration: 0.6, ease: "back.out(3)" })
        .from($("h3", st), { yPercent: 60, opacity: 0, duration: 0.5, ease: "power3.out" }, 0.1)
        .to(p, { scale: 1, rotation: r, duration: 0.6, ease: "back.out(3)" }, 0.25);
    });
  }

  /* =========================================================
     SECTORS — sticker cards pop in tilted, straighten on hover
     ========================================================= */
  function initSectors() {
    var cards = $$(".sector");
    cards.forEach(function (c) {
      var r = readRot(c);
      gsap.set(c, { rotation: r });
      if (!canHover) return;
      c.addEventListener("mouseenter", function () { gsap.to(c, { rotation: 0, y: -8, scale: 1.02, duration: 0.5, ease: "back.out(2)" }); });
      c.addEventListener("mouseleave", function () { gsap.to(c, { rotation: r, y: 0, scale: 1, duration: 0.7, ease: "elastic.out(1, 0.4)" }); });
    });
    ScrollTrigger.batch(".sector", {
      start: "top 90%", once: true,
      onEnter: function (els) { gsap.from(els, { y: 120, scale: 0.7, opacity: 0, duration: 0.9, ease: "back.out(1.7)", stagger: 0.09 }); }
    });
    gsap.from(".sectors-intro", { y: 30, opacity: 0, duration: 0.9, ease: "power3.out", scrollTrigger: { trigger: ".sectors-intro", start: "top 88%", once: true } });
  }

  /* =========================================================
     TELES AGENT — scripted conversation plays when in view
     ========================================================= */
  function initAgent(anim) {
    var body = $(".agent-body");
    if (!body) return;
    var script = [
      { from: "user", text: "I run a forex signals channel, can you grow it?" },
      { from: "agent", text: "Forex channels are in scope if the offer is lawful and ad-compliant. What’s your channel link?" },
      { from: "user", text: "Members, India and UAE, around $800" },
      { from: "agent", text: "Got it: members, India and UAE, around $800. What’s your channel link?" },
      { from: "user", text: "Can you guarantee 10,000 members?" },
      { from: "agent", text: "No—we can’t guarantee member counts or profits. To assess fit, what’s your channel link?" }
    ];
    var timers = [];
    function clear() { timers.forEach(clearTimeout); timers = []; body.innerHTML = ""; }
    function add(m) {
      var el = document.createElement("div");
      el.className = "msg msg--" + m.from;
      el.textContent = m.text;
      body.appendChild(el);
      if (anim) gsap.from(el, { scale: 0.5, opacity: 0, y: 20, duration: 0.5, ease: "back.out(2)" });
      body.scrollTop = body.scrollHeight;
    }
    function play() {
      clear();
      if (!anim) { script.forEach(add); return; }
      var t = 400;
      script.forEach(function (m) {
        if (m.from === "agent") {
          timers.push(setTimeout(function () {
            var ty = document.createElement("div"); ty.className = "typing"; ty.innerHTML = "<i></i><i></i><i></i>";
            body.appendChild(ty); body.scrollTop = body.scrollHeight;
          }, t));
          t += 900;
          timers.push(setTimeout(function () { var ty = $(".typing", body); if (ty) ty.remove(); add(m); }, t));
        } else {
          timers.push(setTimeout(function () { add(m); }, t));
        }
        t += 1500;
      });
    }
    $(".agent-replay").addEventListener("click", play);
    if (!anim) { play(); return; }
    ScrollTrigger.create({ trigger: ".agent-chat", start: "top 75%", once: true, onEnter: play });
    gsap.from(".agent-chat", { y: 100, rotation: 8, opacity: 0, duration: 1.1, ease: "back.out(1.4)", scrollTrigger: { trigger: ".agent", start: "top 75%", once: true } });
  }

  /* =========================================================
     REACH GLOBE — canvas dot globe, drag to spin, city markers,
     arcs between hubs; renders only while on screen
     ========================================================= */
  function initGlobe() {
    var canvas = $(".globe");
    if (!canvas || !canvas.getContext) return;
    var ctx = canvas.getContext("2d");
    var D2R = Math.PI / 180;
    var cities = [
      ["Mumbai", 19.07, 72.88, 1], ["Surat", 21.17, 72.83, 0, 1], ["Delhi", 28.61, 77.21], ["Dubai", 25.2, 55.27, 1], ["Abu Dhabi", 24.45, 54.38, 0, 1],
      ["London", 51.51, -0.13], ["New York", 40.71, -74.01], ["Singapore", 1.35, 103.82], ["Istanbul", 41.01, 28.98],
      ["Kyiv", 50.45, 30.52], ["São Paulo", -23.55, -46.63], ["Lagos", 6.52, 3.38]
    ].map(function (c) { return { name: c[0], v: vec(c[1], c[2]), hot: !!c[3], quiet: !!c[4] }; });
    var byName = {}; cities.forEach(function (c) { byName[c.name] = c; });
    var arcs = [["Mumbai", "Dubai"], ["Dubai", "London"], ["Mumbai", "Singapore"], ["Dubai", "New York"], ["Dubai", "Lagos"], ["Mumbai", "Istanbul"], ["London", "São Paulo"]];
    var dots = [], N = 1100, golden = Math.PI * (3 - Math.sqrt(5));
    for (var i = 0; i < N; i++) {
      var y = 1 - (i / (N - 1)) * 2, r = Math.sqrt(1 - y * y), th = golden * i;
      dots.push([Math.cos(th) * r, y, Math.sin(th) * r]);
    }
    var rot = -88 * D2R, tilt = -18 * D2R, vel = reduce ? 0 : 0.0012, dragging = false, lastX = 0, visible = false, raf = 0, W = 0, H = 0, dpr = 1, tick = 0;

    function vec(lat, lon) { lat *= D2R; lon *= D2R; return [Math.cos(lat) * Math.sin(lon), Math.sin(lat), Math.cos(lat) * Math.cos(lon)]; }
    function proj(p, lift) {
      lift = lift || 1;
      var cr = Math.cos(rot), sr = Math.sin(rot);
      var x = p[0] * cr + p[2] * sr, z = -p[0] * sr + p[2] * cr, y = p[1];
      var ct = Math.cos(tilt), st = Math.sin(tilt);
      var y2 = y * ct - z * st, z2 = y * st + z * ct;
      var R = Math.min(W, H) * 0.4 * lift;
      return { X: W / 2 + x * R, Y: H / 2 - y2 * R, z: z2 };
    }
    function slerp(a, b, t) {
      var d = Math.max(-1, Math.min(1, a[0] * b[0] + a[1] * b[1] + a[2] * b[2])), om = Math.acos(d), so = Math.sin(om);
      if (so < 1e-6) return a;
      var k1 = Math.sin((1 - t) * om) / so, k2 = Math.sin(t * om) / so;
      return [a[0] * k1 + b[0] * k2, a[1] * k1 + b[1] * k2, a[2] * k1 + b[2] * k2];
    }
    function resize() {
      dpr = Math.min(2, window.devicePixelRatio || 1);
      var rect = canvas.getBoundingClientRect(); W = rect.width; H = rect.height;
      canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      draw();
    }
    function draw() {
      if (!W) return;
      ctx.clearRect(0, 0, W, H);
      var R = Math.min(W, H) * 0.4;
      ctx.beginPath(); ctx.arc(W / 2, H / 2, R, 0, Math.PI * 2);
      ctx.fillStyle = "#F9E2E1"; ctx.fill();
      ctx.lineWidth = 2.5; ctx.strokeStyle = "#0C0C0D"; ctx.stroke();
      for (var i = 0; i < dots.length; i++) {
        var q = proj(dots[i]);
        if (q.z < 0) continue;
        ctx.globalAlpha = 0.15 + 0.6 * q.z;
        ctx.fillStyle = "#0C0C0D";
        ctx.beginPath(); ctx.arc(q.X, q.Y, 0.8 + 1.4 * q.z, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
      arcs.forEach(function (a, ai) {
        var A = byName[a[0]].v, B = byName[a[1]].v, prev = null;
        ctx.strokeStyle = "#FF5C00"; ctx.lineWidth = 2.5; ctx.lineCap = "round";
        for (var s = 0; s <= 40; s++) {
          var t = s / 40, q = proj(slerp(A, B, t), 1 + 0.16 * Math.sin(t * Math.PI));
          if (prev && q.z > -0.05 && prev.z > -0.05) { ctx.beginPath(); ctx.moveTo(prev.X, prev.Y); ctx.lineTo(q.X, q.Y); ctx.stroke(); }
          prev = q;
        }
        var head = ((tick * 0.006 + ai * 0.23) % 1.3);
        if (head <= 1) {
          var h = proj(slerp(A, B, head), 1 + 0.16 * Math.sin(head * Math.PI));
          if (h.z > 0) { ctx.fillStyle = "#0C0C0D"; ctx.beginPath(); ctx.arc(h.X, h.Y, 4, 0, Math.PI * 2); ctx.fill(); }
        }
      });
      ctx.font = "600 12px 'Inter Tight', sans-serif";
      cities.forEach(function (c) {
        var q = proj(c.v);
        if (q.z < 0.02) return;
        if (c.hot) {
          var pulse = (tick * 0.02) % 1;
          ctx.strokeStyle = "rgba(255,92,0," + (1 - pulse) + ")"; ctx.lineWidth = 2;
          ctx.beginPath(); ctx.arc(q.X, q.Y, 6 + pulse * 16, 0, Math.PI * 2); ctx.stroke();
        }
        ctx.fillStyle = "#FF5C00"; ctx.strokeStyle = "#0C0C0D"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(q.X, q.Y, c.hot ? 7 : 5, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
        if (q.z > 0.3 && !c.quiet) {
          var tw = ctx.measureText(c.name).width, px = q.X + 10, py = q.Y - 22;
          ctx.globalAlpha = Math.min(1, (q.z - 0.3) * 4);
          ctx.fillStyle = "#0C0C0D";
          roundRect(px, py, tw + 16, 20, 10); ctx.fill();
          ctx.fillStyle = "#fff"; ctx.fillText(c.name, px + 8, py + 14);
          ctx.globalAlpha = 1;
        }
      });
    }
    function roundRect(x, y, w, h, r) {
      ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
      ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
    }
    function loop() {
      raf = 0;
      if (!visible) return;
      tick++;
      if (!dragging) { rot += vel; vel += ((reduce ? 0 : 0.0012) - vel) * 0.02; }
      draw();
      raf = requestAnimationFrame(loop);
    }
    function start() { if (!raf) raf = requestAnimationFrame(loop); }

    canvas.addEventListener("pointerdown", function (e) { dragging = true; lastX = e.clientX; canvas.setPointerCapture(e.pointerId); });
    canvas.addEventListener("pointermove", function (e) {
      if (!dragging) return;
      var dx = e.clientX - lastX; lastX = e.clientX;
      rot += dx * 0.006; vel = dx * 0.006;
      if (!visible || reduce) draw();
    });
    ["pointerup", "pointercancel"].forEach(function (ev) { canvas.addEventListener(ev, function () { dragging = false; }); });
    window.addEventListener("resize", debounce(resize, 150));
    if ("IntersectionObserver" in window) {
      new IntersectionObserver(function (en) { visible = en[0].isIntersecting; if (visible) start(); }).observe(canvas);
    } else { visible = true; start(); }
    resize();
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(draw);
  }

  /* ---------- Helpers ---------- */
  function readRot(el) { return parseFloat(getComputedStyle(el).getPropertyValue("--r")) || 0; }
  function wrapPillText(p) {
    if ($(".pill-mask", p)) return;
    var m = document.createElement("span"); m.className = "pill-mask";
    var s = document.createElement("span"); s.textContent = p.textContent;
    p.textContent = ""; m.appendChild(s); p.appendChild(m);
  }
  function debounce(fn, ms) { var t; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }
})();
